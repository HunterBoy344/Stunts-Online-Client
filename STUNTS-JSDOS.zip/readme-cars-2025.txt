 __________________________________________________________________
/      _____          __    _____  __                 __           \
|     /__  /  _____  / /__ / ___/ / /_ __  __ ____   / /_ _____    |
|       / /  / __ `// //_/ \__ \ / __// / / // __ \ / __// ___/    |
|      / /__/ /_/ // ,<   ___/ // /_ / /_/ // / / // /_ (__  )     |
|     /____/\__,_//_/|_| /____/ \__/ \__,_//_/ /_/ \__//____/      |
|                      HTTPS://ZAK.STUNTS.HU                       |
\__________________________________________________________________/
 \\==============================================================//
  ||================   S E A S O N    2 0 2 5   ================||
 //==============================================================\\
||                                                                ||
||    This archive contains the custom cars required for          ||
||    taking part in the 2025 season of ZakStunts.                ||
||                                                                ||
||    In this car pack:                                           ||
||                                                                ||
||    - M2CA : Chevrolet Camaro, by Alan Rotoi                    ||
||    - DIA3 : Lamborghini Diablo VT, by Ryoma                    ||
||    - ZLET : Lotus Esprit Turbo, by Zapper                      ||
||    - DMCB : Mercedes-Benz 190 E DTM, by Overdrijf              ||
||    - OXIA : Peugeot Oxia, by Ryoma                             ||
||                                                                ||
||    Copy the car files into your Stunts directory, start the    ||
||    game, and the new models will appear in the car             ||
||    selection screen.                                           ||
||                                                                ||
||    All cars are designed for Stunts version Broderbund 1.1,    ||
||    which can be downloaded from our website.                   ||
||                                                                ||
|| -------------------------------------------------------------- ||
||                                                                ||
||    To join the competition, register as a racer on             ||
||                                                                ||
||                    https://zak.stunts.hu                       ||
||                                                                ||
||    Then download the current track, and submit your replays    ||
||    using the web form. If you have any questions feel free     ||
||    to ask in the shoutbox, or in the forum.                    ||
||                                                                ||
||    I wish you happy and succesful racing, try your best,       ||
||    and visit us again!                                         ||
||                                               Zak McKracken    ||
||                                                                ||
||________________________________________________________________||
\\                                                                //
 \\                   HTTPS://ZAK.STUNTS.HU                      //
__\\____________________________________________________________//__

 /================================================================\
<  C O P Y R I G H T   B Y   Z A K   M C K R A C K E N ,  2 0 2 5  >
 \================================================================/
