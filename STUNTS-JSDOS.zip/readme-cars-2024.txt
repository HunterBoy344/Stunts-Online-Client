 __________________________________________________________________
/      _____          __    _____  __                 __           \
|     /__  /  _____  / /__ / ___/ / /_ __  __ ____   / /_ _____    |
|       / /  / __ `// //_/ \__ \ / __// / / // __ \ / __// ___/    |
|      / /__/ /_/ // ,<   ___/ // /_ / /_/ // / / // /_ (__  )     |
|     /____/\__,_//_/|_| /____/ \__/ \__,_//_/ /_/ \__//____/      |
|                       HTTP://ZAK.STUNTS.HU                       |
\__________________________________________________________________/
 \\==============================================================//
  ||================   S E A S O N    2 0 2 4   ================||
 //==============================================================\\
||                                                                ||
||    This archive contains the custom cars required for          ||
||    taking part in the 2024 season of ZakStunts.                ||
||                                                                ||
||    In this car pack:                                           || 
||                                                                ||
||    - ZF40 : Ferrari F40, by Zapper                             ||
||    - 50FT : 1957 Ford Thunderbird, by Alan Rotoi               ||
||    - STRA : Lancia Stratos, by Ryoma                           ||
||    - LOLA : Lola Cosworth Indy, by Alan Rotoi                  ||
||    - ZGT3 : LWT-ZR1 GT3, By Duplode                            ||
||                                                                ||
||    Copy the car files into your Stunts directory, start the    ||
||    game, and the new models will appear in the car             ||
||    selection screen.                                           ||
||                                                                ||
||    All cars are designed for Stunts version Broderbund 1.1,    ||
||    which can be downloaded from our website.                   ||
||                                                                ||
|| -------------------------------------------------------------- ||
||                                                                ||
||    To join the competition, register as a racer on             ||
||                                                                ||
||                    https://zak.stunts.hu                       ||
||                                                                ||
||    Then download the current track, and submit your replays    ||
||    using the web form. If you have any questions feel free     ||
||    to ask me in mail, or from everyone at the forum or         ||
||    chat.                                                       ||
||                                                                ||
||    I wish you happy and succesful racing, try your best,       ||
||    and visit us again!                                         ||
||                                               Zak McKracken    ||
||                                                                ||
||________________________________________________________________||
\\                                                                //
 \\                    HTTPS://ZAK.STUNTS.HU                     //
__\\____________________________________________________________//__

 /================================================================\
<  C O P Y R I G H T   B Y   Z A K   M C K R A C K E N ,  2 0 2 4  >
 \================================================================/
