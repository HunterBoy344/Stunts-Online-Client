		
                       4D/Stunts Replay Data Viewer
                       ============================

                               Version 1.25

                       Copyright 1997 Lukas Loehrer

                            December, 12th 1997




This program is freeware. This means that you can use it free of charge and
at your own risk. So, if it should cause damage to your game, your hard drive,
your computer of even your dog, it is not my fault. You are permitted to 
reverse engineer, decompile, tamper with, or modify this program in any way,
but if you bother to do so, you should seriously consider getting a life ;).
Anyway, enough of this very formal legal talk; just have fun using it!



1. What is this program?
========================

RPLINFO is a little utility that allows you to view some data of replay files
(*.rpl), that were recorded with Mindscape's 4D Stunts Driving or Broderbund's 
Stunts. That data is:

	o the name of the track used in the replay
	o the time achieved (cf. question 4)
	o the opponent's name
	o your and the opponent's car and their colour (cf. question 5)
	o the gear shift mode (auto or manual)
	
RPLINFO also lets you extract the track that was used to record the replay
save it in a file.

2. Why should anybody want such a program?
==========================================

The need for this tool arose when I held a driving contest for 4D/Stunts and
therefore had to deal with a lot of replay files. It became tedious to always
start the game only to determine the colour of the car. RPLINFO solves this
problem. Under Win95, you can create a shortcut to it on the desktop and then
drag any replay file on it. This gives you a very elaborate way to quickly check
e.g. the time you achieved in a replay.

3. How do I use this program?
=============================

Because I am such a poor and lazy programmer, RPL info does not come with a 
fancy GUI. Instead, it's purely command line (remember: real men never touch
a mouse ;). So here's the syntax:

RPLINFO filename [-t] [-tn trackfile] [-o]

where 'filename' is the replay you want to work with. If 'filename' exists 
in the current directory, its data will be shown on screen. Additionally 
you can specify the following options:

-t	causes RPL info to extract the track from the replay file. By default
	the original file name will be used and no files will be overwritten.

-tn	lets you choose the name that the track is saved under

-o	RPLINFO will overwrite existing tracks without asking if this option is
	given.

Examples:

RPLINFO foobar.rpl
	displays the data of the replay called 'foobar.rpl'

RPLINFO foobar
	dito

RPLINFO foobar -t -tn turnip.trk -o
	displays the data of the replay called 'foobar.rpl' and
	saves the track under the name 'turnip.trk' no matter if
	such a file already exists.

4. What does '(finished)' after the time mean?
==============================================

If the string '(finished)' is displayed behind a time, RPLINFO guessed that you
completed a whole lap in that replay. It will then subtract one second from the 
actual length of the replay in order to get the time it took you to for the lap.
If '(finished)' is not shown, RPLINFO will display the total length of the replay.

The method used to determine whether or not the lap was completed is *not* entirely
fool proof. In fact, RPLINFO may tell you that the lap was finished altough it
was *not*; however, it will never tell you that the lap was not finished if it
actually *was*. (cf q. 9)

5. Why does it say 'Unknown car' or 'Unknown colour'? 
=====================================================

This is because RPLINFO only knows the standard car that came with the game. If any
additional home-made cars were used to record a replay, RPLINFO will not be able to
tell its name or its colour. 
The colour of a car seems to be stored somewhere in the ST????.p3s files. If you 
happen to know the exact location, please tell me.


6. Can I report a bug?
======================

Please do so. Contact me by e-mail and try to describe you experience in way
that enables me to reproduce the steps that lead to the occurrence to the bug.
If possible, you should also send me the replay that provokes the bug. I will 
then do my best to fix it.

7. I have more questions
========================

You are welcome to ask them via e-mail.

8. I love (or hate) this program and want to tell you about it
==============================================================

Contact me under:

lukasl@dataway.ch  (Lukas Loehrer)

9. What is that 'not fool proof' method to determine if a lap was finished?
===========================================================================

A finished replay is usually exactly one second longer than the lap time that was
achieved. During that additional second, the game doesn't record any key strokes.
Because the key code sampling frequency is 20 and the value for 'no activity' is
'00', we can find at least twenty 00s at the end of a finished replay. RPLINFO 
checks that to determine whether or not a replay ended with the completion of a lap.

The catch to this method is that RPLINFO will consider every replay that ends with
one second of inactivity as 'finished' and even worse, it will display a wrong time.

10. Why is no source code included?
===================================

Hmm.. because I am a bit embarrassed of it. RPLINFO was 'developed' in quite a rush so
there was no time to employ any sophisticated programming techniques. If you want to
have it anyway, tell me and I'll send it to you.


That's it. I hope this programme will be of any use to you.  Keep 4Ding or
Stunting and have a good time,

  Lukas Loehrer


