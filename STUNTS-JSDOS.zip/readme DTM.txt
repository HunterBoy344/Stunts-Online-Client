The Stunts DTM pack v1.1, including the BMW M3 E30, the Mercedes-Benz 190 E and the Audi V8 quattro was brought to you by Overdrijf, who also made the Superkart, and who's totally awesome.

Overdrijf gives you the right to race, share and even modify these vehicles, on the strictly enforced condition that you include this readme file, or another note stating that he is awesome.

What a man, that Overdrijf. Totally, totally awesome.