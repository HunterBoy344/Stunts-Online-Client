 __________________________________________________________________
/      _____          __    _____  __                 __           \
|     /__  /  _____  / /__ / ___/ / /_ __  __ ____   / /_ _____    |
|       / /  / __ `// //_/ \__ \ / __// / / // __ \ / __// ___/    |
|      / /__/ /_/ // ,<   ___/ // /_ / /_/ // / / // /_ (__  )     |
|     /____/\__,_//_/|_| /____/ \__/ \__,_//_/ /_/ \__//____/      |
|                       HTTP://ZAK.STUNTS.HU                       |
\__________________________________________________________________/
 \\==============================================================//
  ||================   S E A S O N    2 0 2 3   ================||
 //==============================================================\\
||                                                                ||
||    This archive contains the custom cars required for          ||
||    taking part in the 2023 season of ZakStunts.                ||
||                                                                ||
||    In this car pack:                                           || 
||                                                                ||
||    - CERV : Chevrolet Corvette CERV III, by KyLiE              ||
||    - DC70 : 1970 Dodge Challenger R/T Hardtop, by CTG          ||
||    - DMCB : Mercedes-Benz 190 E DTM, by Overdrijf              ||
||    - DTPA : De Tomaso Pantera GTS, by Alan Rotoi               ||
||    - ZMP4 : McLaren Honda MP4/4, by Zapper                     ||
||                                                                ||
||    Copy the car files into your Stunts directory, start the    ||
||    game, and the new models will appear in the car             ||
||    selection screen.                                           ||
||                                                                ||
||    All cars are designed for Stunts version Broderbund 1.1,    ||
||    which can be downloaded from our website.                   ||
||                                                                ||
|| -------------------------------------------------------------- ||
||                                                                ||
||    To join the competition, register as a racer on             ||
||                                                                ||
||                    https://zak.stunts.hu                       ||
||                                                                ||
||    Then download the current track, and submit your replays    ||
||    using the web form. If you have any questions feel free     ||
||    to ask me in mail, or from everyone at the forum or         ||
||    chat.                                                       ||
||                                                                ||
||    I wish you happy and succesful racing, try your best,       ||
||    and visit us again!                                         ||
||                                               Zak McKracken    ||
||                                                                ||
||________________________________________________________________||
\\                                                                //
 \\                    HTTPS://ZAK.STUNTS.HU                     //
__\\____________________________________________________________//__

 /================================================================\
<  C O P Y R I G H T   B Y   Z A K   M C K R A C K E N ,  2 0 2 3  >
 \================================================================/